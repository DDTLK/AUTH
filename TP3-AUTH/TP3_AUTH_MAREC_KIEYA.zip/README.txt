TP3 : accréditation anonyme et coloriage de graphe

Commandes pour compiler et lancer le programme:

	gcc -g -o tp3 meg.c graph.c node.c tp3_AUTH.c md5.c

	./tp3